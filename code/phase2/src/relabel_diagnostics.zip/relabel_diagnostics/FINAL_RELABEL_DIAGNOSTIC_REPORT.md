# ASIL NLU Relabeling & Empirical Learnability Report

### Objective
This report empirically demonstrates whether the final canonical ontology is learnable from the frozen Whisper representations actually used by the downstream NLU. It evaluates semantic coherence against acoustic representation geometry.

### Learnability Gate Results (Linear SVM on Whisper `attention_pool`)
| Head        |   Classes |   Target |   Macro_F1 |   Weighted_F1 |   Bal_Acc |      Acc | Gate_Status   |
|:------------|----------:|---------:|-----------:|--------------:|----------:|---------:|:--------------|
| intent      |         4 |     0.7  |   0.322688 |      0.486418 |  0.32346  | 0.483737 | FAIL          |
| entity_type |         3 |     0.7  |   0.399853 |      0.434336 |  0.399557 | 0.437186 | FAIL          |
| urgency     |         4 |     0.75 |   0.291682 |      0.478533 |  0.294711 | 0.483528 | FAIL          |
| emotion     |         7 |     0.65 |   0.18612  |      0.223605 |  0.188333 | 0.217028 | FAIL          |

### Interpretation
* Pass/Fail denotes empirical learnability based on the development targets, **not** a mathematical guarantee of perfect classification for the final MLP.
* Check `learnability_gate_per_class.csv` for problematic overlapping classes.
* Confusion matrices and PCA plots are available in the diagnostic directories.
