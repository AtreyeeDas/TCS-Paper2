# ASIL Final Ontology Human Review Instructions

Review the generated `{head}_review.csv` files in this directory. 
Each row represents **ONE CANONICAL CLASS**, not an individual dataset row.

### How to Review:
1. Open the CSV file (in Excel, VS Code, or text editor).
2. Inspect `canonical_label`, `definition`, and `original_labels`.
3. If satisfied, leave `review_status` as **`APPROVE`**.
4. If you want to rename a class, edit the text in `canonical_label` directly and set `review_status` to **`APPROVE`**.
5. If you want to merge two proposed classes, give them the exact same `canonical_label` and set `review_status` to **`APPROVE`**.
6. If a proposed group is invalid, set `review_status` to **`REJECT`** or **`SPLIT`**.
7. Once finished, run `lock_and_apply_ontology.py` to compile `ontology_v1.json` and automatically remap the entire master dataset.
