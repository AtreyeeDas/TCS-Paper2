
ROBUST NLU 6000 DATASET

6000 utterances
600 semantic scenarios
10 paraphrase variants per scenario

SCENARIO SPLIT
420 train scenarios
90 validation scenarios
90 unseen scenarios

CRITICAL:
All 10 paraphrases of a scenario remain in exactly one split.
There is no utterance-level random leakage across splits.

The unseen split therefore contains scenarios never observed during training.

LEXICAL DESIGN
Ambiguous/common vocabulary is intentionally reused across domains:
assessment, review, analysis, case, report, risk, exposure, record, monitoring, adjustment, strategy, screening, model, account, incident, resolution, validation, authorization, transfer, response

The intent is to prevent single-keyword shortcuts.

GENERAL DOMAIN
General samples have:
subdomain_label = NONE
topic_label = NONE
document_type_label = NONE

RECOMMENDED TRAINING:
Use split == train for fitting.
Use split == validation for model selection.
Use split == unseen only once for final generalization reporting.

LIMITATION:
This is a synthetic controlled benchmark. It is not a guarantee of
real-world speech/NLU accuracy.
